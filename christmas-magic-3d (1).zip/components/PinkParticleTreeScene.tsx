
import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';

/**
 * CINEMATIC CONFIGURATION
 */
const CONFIG = {
  TREE_PARTICLES: 500000, 
  SILVER_ORNAMENT_PARTICLES: 800, 
  SNOW_PARTICLES: 15000,  
  HEART_PARTICLES: 15000, 
  WISH_METEOR_PARTICLES: 100000, // Increased for a denser, richer tail
  SPIRAL_METEOR_PARTICLES: 4500, 
  COLOR_BLUE_PINK: new THREE.Color(0xd8d8ff), 
  COLOR_SILVER_GLOW: new THREE.Color(0xe8e8e8),
  COLOR_GOLD_METALLIC: new THREE.Color(0xffd700),
  BLOOM_STRENGTH: 0.65, 
};

interface SceneProps {
  isMagicTriggered: boolean;
  wishTrigger?: number;
  photos?: string[];
}

const PinkParticleTreeScene: React.FC<SceneProps> = ({ isMagicTriggered, wishTrigger, photos = [] }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const magicRef = useRef(isMagicTriggered);
  const wishAnimRef = useRef({ startTime: 0, active: false });
  const fairyLightsRef = useRef<{ light: THREE.PointLight, offset: number }[]>([]);
  const photoMeshesRef = useRef<THREE.Group[]>([]);
  const textureLoader = useRef(new THREE.TextureLoader());

  useEffect(() => {
    magicRef.current = isMagicTriggered;
  }, [isMagicTriggered]);

  useEffect(() => {
    if (wishTrigger && wishTrigger > 0) {
      wishAnimRef.current = { startTime: Date.now(), active: true };
    }
  }, [wishTrigger]);

  useEffect(() => {
    photos.forEach((photoUrl, index) => {
      if (photoMeshesRef.current[index]) {
        textureLoader.current.load(photoUrl, (texture) => {
          texture.colorSpace = THREE.SRGBColorSpace;
          const photoGroup = photoMeshesRef.current[index];
          photoGroup.children.forEach(child => {
            if (child instanceof THREE.Mesh && (child.name === 'photoPlane' || child.name === 'backPlane')) {
              const mat = child.material as THREE.MeshStandardMaterial;
              mat.map = texture;
              mat.emissiveMap = texture;
              mat.emissive.set(0xffffff);
              mat.emissiveIntensity = 0.6;
              mat.color.set(0xffffff);
              mat.opacity = 1.0;
              mat.needsUpdate = true;
            }
          });
        });
      }
    });
  }, [photos]);

  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 5, 18);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1; 
    mountRef.current.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.autoRotate = false;
    controls.target.set(0, 4.5, 0);

    const light1 = new THREE.PointLight(0xffffff, 10, 35);
    light1.position.set(10, 15, 10);
    scene.add(light1);

    const starGlowLight = new THREE.PointLight(CONFIG.COLOR_BLUE_PINK, 0.6, 15);
    starGlowLight.position.set(0, 9.4, 0);
    scene.add(starGlowLight);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.25);
    scene.add(ambientLight);

    const treeGroup = new THREE.Group();
    scene.add(treeGroup);

    const treeVertexShader = `
      uniform float uTime;
      uniform float uMagic;
      attribute float aScale;
      attribute float aOffset;
      attribute vec3 aColor;
      varying vec3 vColor;
      varying float vTwinkle;
      
      void main() {
        vec3 pos = position;
        float t = uTime * 0.4 + aOffset;
        pos.y += sin(t) * 0.05;
        pos.x += cos(t * 1.1) * 0.03;
        float freq = 12.0;
        float amp = 0.025;
        pos.x += sin(uTime * freq + aOffset * 1.3) * amp;
        pos.y += cos(uTime * (freq + 0.7) + aOffset * 1.7) * amp;
        pos.z += sin(uTime * (freq - 0.4) + aOffset * 1.1) * amp;
        if(uMagic > 0.01) {
          pos += normalize(pos) * sin(uTime * 4.0 + aOffset) * 0.18 * uMagic;
        }
        vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
        gl_Position = projectionMatrix * mvPosition;
        gl_PointSize = aScale * (450.0 / -mvPosition.z);
        vColor = aColor;
        vTwinkle = 0.3 + 0.7 * pow(0.5 + 0.5 * sin(uTime * 3.8 + aOffset * 22.0), 3.0);
      }
    `;

    const treeFragmentShader = `
      varying vec3 vColor;
      varying float vTwinkle;
      void main() {
        float r = distance(gl_PointCoord, vec2(0.5));
        if (r > 0.5) discard;
        float strength = pow(1.0 - (r * 2.0), 2.5);
        gl_FragColor = vec4(vColor, strength * vTwinkle * 1.1);
      }
    `;

    const treeGeo = new THREE.BufferGeometry();
    const posArr = new Float32Array(CONFIG.TREE_PARTICLES * 3);
    const colArr = new Float32Array(CONFIG.TREE_PARTICLES * 3);
    const scaleArr = new Float32Array(CONFIG.TREE_PARTICLES);
    const offsetArr = new Float32Array(CONFIG.TREE_PARTICLES);

    for (let i = 0; i < CONFIG.TREE_PARTICLES; i++) {
      const y = Math.random() * 9;
      const t = Math.random() * Math.PI * 2;
      const maxRadius = (9 - y) / 9 * 3.6;
      const r = (0.28 + Math.pow(Math.random(), 1.45) * 0.72) * maxRadius;
      posArr[i * 3] = Math.cos(t) * r;
      posArr[i * 3 + 1] = y;
      posArr[i * 3 + 2] = Math.sin(t) * r;
      const radialRatio = r / (maxRadius + 0.1);
      let pColor = new THREE.Color(0xffb6c1);
      if (radialRatio > 0.55) pColor.lerp(new THREE.Color(0xffd700), (radialRatio - 0.55) * 2.5);
      colArr[i * 3] = pColor.r; colArr[i * 3 + 1] = pColor.g; colArr[i * 3 + 2] = pColor.b;
      scaleArr[i] = Math.random() > 0.98 ? 0.12 + Math.random() * 0.15 : 0.02 + Math.random() * 0.04;
      offsetArr[i] = Math.random() * Math.PI * 100;
    }

    treeGeo.setAttribute('position', new THREE.BufferAttribute(posArr, 3));
    treeGeo.setAttribute('aColor', new THREE.BufferAttribute(colArr, 3));
    treeGeo.setAttribute('aScale', new THREE.BufferAttribute(scaleArr, 1));
    treeGeo.setAttribute('aOffset', new THREE.BufferAttribute(offsetArr, 1));

    const treeMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uMagic: { value: 0 } },
      vertexShader: treeVertexShader, fragmentShader: treeFragmentShader,
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false
    });
    const treePoints = new THREE.Points(treeGeo, treeMat);
    treeGroup.add(treePoints);

    const createPhotoFrame = (pos: THREE.Vector3, rot: THREE.Euler) => {
      const group = new THREE.Group();
      const frameWidth = 0.53;
      const frameHeight = 0.73;
      const frameDepth = 0.03;
      const frameGeo = new THREE.BoxGeometry(frameWidth, frameHeight, frameDepth);
      const frameMat = new THREE.MeshStandardMaterial({ 
        color: CONFIG.COLOR_GOLD_METALLIC, 
        metalness: 1.0, 
        roughness: 0.1,
        emissive: CONFIG.COLOR_GOLD_METALLIC,
        emissiveIntensity: 0.1
      });
      const frameMesh = new THREE.Mesh(frameGeo, frameMat);
      group.add(frameMesh);
      const photoPlaneGeo = new THREE.PlaneGeometry(frameWidth * 0.88, frameHeight * 0.88);
      const photoPlaneMat = new THREE.MeshStandardMaterial({ 
        color: 0x111111, 
        roughness: 0.3,
        transparent: true,
        opacity: 0.8,
        emissive: 0x000000,
        emissiveIntensity: 0.0
      });
      const photoPlane = new THREE.Mesh(photoPlaneGeo, photoPlaneMat);
      photoPlane.name = 'photoPlane';
      photoPlane.position.z = frameDepth / 2 + 0.005; 
      group.add(photoPlane);
      const backPlane = new THREE.Mesh(photoPlaneGeo, photoPlaneMat.clone());
      backPlane.name = 'backPlane';
      backPlane.position.z = -(frameDepth / 2 + 0.005);
      backPlane.rotation.y = Math.PI;
      group.add(backPlane);
      group.position.copy(pos);
      group.rotation.copy(rot);
      return group;
    };

    const framePositions = [
      new THREE.Vector3(2.5, 2.5, 2.0),
      new THREE.Vector3(-2.8, 3.2, 1.5),
      new THREE.Vector3(1.5, 5.5, 1.2),
      new THREE.Vector3(-1.2, 6.0, -1.8),
      new THREE.Vector3(0.5, 4.0, -2.5),
      new THREE.Vector3(-0.8, 1.5, 3.2),
    ];

    photoMeshesRef.current = framePositions.map((pos, i) => {
      const frame = createPhotoFrame(pos, new THREE.Euler(0, Math.random() * Math.PI, 0));
      treeGroup.add(frame);
      return frame;
    });

    const silverGeo = new THREE.BufferGeometry();
    const sPosArr = new Float32Array(CONFIG.SILVER_ORNAMENT_PARTICLES * 3);
    const sOffsetArr = new Float32Array(CONFIG.SILVER_ORNAMENT_PARTICLES);
    const sScaleArr = new Float32Array(CONFIG.SILVER_ORNAMENT_PARTICLES);

    for (let i = 0; i < CONFIG.SILVER_ORNAMENT_PARTICLES; i++) {
      const y = Math.random() * 8.5;
      const t = Math.random() * Math.PI * 2;
      const maxRadius = (9 - y) / 9 * 3.6;
      const r = maxRadius * (0.95 + Math.random() * 0.1); 
      sPosArr[i * 3] = Math.cos(t) * r;
      sPosArr[i * 3 + 1] = y;
      sPosArr[i * 3 + 2] = Math.sin(t) * r;
      sOffsetArr[i] = Math.random() * 1000;
      sScaleArr[i] = 0.07 + Math.random() * 0.1;
    }

    silverGeo.setAttribute('position', new THREE.BufferAttribute(sPosArr, 3));
    silverGeo.setAttribute('aOffset', new THREE.BufferAttribute(sOffsetArr, 1));
    silverGeo.setAttribute('aScale', new THREE.BufferAttribute(sScaleArr, 1));

    const silverMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uColor: { value: CONFIG.COLOR_SILVER_GLOW }, uMagic: { value: 0 } },
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
      vertexShader: `
        uniform float uTime;
        attribute float aOffset;
        attribute float aScale;
        varying float vGlow;
        void main() {
          vec3 pos = position;
          pos.x += sin(uTime * 0.5 + aOffset) * 0.05;
          pos.z += cos(uTime * 0.5 + aOffset) * 0.05;
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_PointSize = aScale * (800.0 / -mvPosition.z);
          gl_Position = projectionMatrix * mvPosition;
          vGlow = 0.4 + 0.6 * pow(0.5 + 0.5 * sin(uTime * 2.5 + aOffset), 4.0);
        }
      `,
      fragmentShader: `
        uniform vec3 uColor;
        varying float vGlow;
        void main() {
          float r = distance(gl_PointCoord, vec2(0.5));
          if (r > 0.5) discard;
          gl_FragColor = vec4(uColor, pow(1.0 - r * 2.0, 2.0) * vGlow * 1.5);
        }
      `
    });
    const silverPoints = new THREE.Points(silverGeo, silverMat);
    treeGroup.add(silverPoints);

    const lightColors = [0xff6666, 0xffff66, 0x66ff66, 0x66ffff, 0xff66ff];
    fairyLightsRef.current = [];
    for (let i = 0; i < 40; i++) {
      const y = 0.5 + Math.random() * 8.0;
      const t = Math.random() * Math.PI * 2;
      const r = (9 - y) / 9 * 3.6 + 0.3;
      const pLight = new THREE.PointLight(lightColors[i % lightColors.length], 0.4, 5);
      pLight.position.set(Math.cos(t) * r, y, Math.sin(t) * r);
      treeGroup.add(pLight);
      fairyLightsRef.current.push({ light: pLight, offset: Math.random() * Math.PI * 5 });
    }

    // --- WISH SHOOTING STAR ---
    const wishGeo = new THREE.BufferGeometry();
    const wishP = new Float32Array(CONFIG.WISH_METEOR_PARTICLES * 3);
    const wishS = new Float32Array(CONFIG.WISH_METEOR_PARTICLES);
    const wishO = new Float32Array(CONFIG.WISH_METEOR_PARTICLES);
    const wishOf = new Float32Array(CONFIG.WISH_METEOR_PARTICLES);
    for(let i=0; i<CONFIG.WISH_METEOR_PARTICLES; i++) wishOf[i] = Math.random();
    wishGeo.setAttribute('position', new THREE.BufferAttribute(wishP, 3));
    wishGeo.setAttribute('size', new THREE.BufferAttribute(wishS, 1));
    wishGeo.setAttribute('opacity', new THREE.BufferAttribute(wishO, 1));
    wishGeo.setAttribute('offset', new THREE.BufferAttribute(wishOf, 1));

    const wishMat = new THREE.ShaderMaterial({
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
      uniforms: { uColor: { value: new THREE.Color(0xffffff) }, uTime: { value: 0 } },
      vertexShader: `
        attribute float size;
        attribute float opacity;
        attribute float offset;
        uniform float uTime;
        varying float vOpacity;
        void main() {
          float sparkle = 0.85 + 0.15 * sin(uTime * 300.0 + offset * 1000.0);
          vOpacity = opacity * sparkle;
          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mvPosition;
          gl_PointSize = size * (2000.0 / -mvPosition.z);
        }
      `,
      fragmentShader: `
        uniform vec3 uColor;
        varying float vOpacity;
        void main() {
          float r = distance(gl_PointCoord, vec2(0.5));
          if (r > 0.5) discard;
          // Smaller, sharper head glow
          float headCore = pow(1.0 - r * 2.0, 150.0) * 50.0;
          float glow = pow(1.0 - r * 2.0, 20.0) * 0.15;
          gl_FragColor = vec4(uColor, vOpacity * (headCore + glow));
        }
      `
    });
    const wishShootingStar = new THREE.Points(wishGeo, wishMat);
    wishShootingStar.visible = false;
    wishShootingStar.frustumCulled = false;
    scene.add(wishShootingStar);

    // --- SPIRAL METEOR TRAIL ---
    const spiralGeo = new THREE.BufferGeometry();
    const spirP = new Float32Array(CONFIG.SPIRAL_METEOR_PARTICLES * 3);
    const spirS = new Float32Array(CONFIG.SPIRAL_METEOR_PARTICLES);
    const spirO = new Float32Array(CONFIG.SPIRAL_METEOR_PARTICLES);
    const spirOf = new Float32Array(CONFIG.SPIRAL_METEOR_PARTICLES);
    for (let i = 0; i < CONFIG.SPIRAL_METEOR_PARTICLES; i++) { spirOf[i] = Math.random(); }
    spiralGeo.setAttribute('position', new THREE.BufferAttribute(spirP, 3));
    spiralGeo.setAttribute('size', new THREE.BufferAttribute(spirS, 1));
    spiralGeo.setAttribute('opacity', new THREE.BufferAttribute(spirO, 1));
    spiralGeo.setAttribute('offset', new THREE.BufferAttribute(spirOf, 1));

    const spiralMat = new THREE.ShaderMaterial({
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
      uniforms: { uTime: { value: 0 }, uColor: { value: new THREE.Color(0xffffcc) } },
      vertexShader: `
        attribute float size;
        attribute float opacity;
        attribute float offset;
        uniform float uTime;
        varying float vOpacity;
        void main() {
          float twinkle = 0.6 + 0.4 * sin(uTime * 12.0 + offset * 15.0);
          vOpacity = opacity * twinkle;
          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mvPosition;
          gl_PointSize = size * (1200.0 / -mvPosition.z);
        }
      `,
      fragmentShader: `
        uniform vec3 uColor;
        varying float vOpacity;
        void main() {
          float r = distance(gl_PointCoord, vec2(0.5));
          if (r > 0.5) discard;
          gl_FragColor = vec4(uColor, vOpacity * (1.0 - r * 2.0) * 0.8);
        }
      `
    });
    const spiralPoints = new THREE.Points(spiralGeo, spiralMat);
    treeGroup.add(spiralPoints);

    const heartGeo = new THREE.BufferGeometry();
    const hPosData = new Float32Array(CONFIG.HEART_PARTICLES * 3);
    const hScalesData = new Float32Array(CONFIG.HEART_PARTICLES);
    const hOffsetsData = new Float32Array(CONFIG.HEART_PARTICLES);
    for (let i = 0; i < CONFIG.HEART_PARTICLES; i++) {
      const t = Math.random() * Math.PI * 2;
      const r = Math.pow(Math.random(), 0.5); 
      const x = 16 * Math.pow(Math.sin(t), 3);
      const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
      const scaleFactor = 0.045 * r;
      hPosData[i * 3] = x * scaleFactor;
      hPosData[i * 3 + 1] = y * scaleFactor;
      hPosData[i * 3 + 2] = (Math.random() - 0.5) * 0.15;
      hScalesData[i] = 0.04 + Math.random() * 0.12;
      hOffsetsData[i] = Math.random() * 100;
    }
    heartGeo.setAttribute('position', new THREE.BufferAttribute(hPosData, 3));
    heartGeo.setAttribute('aScale', new THREE.BufferAttribute(hScalesData, 1));
    heartGeo.setAttribute('aOffset', new THREE.BufferAttribute(hOffsetsData, 1));

    const heartMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uColor: { value: CONFIG.COLOR_BLUE_PINK }, uMagic: { value: 0 } },
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
      vertexShader: `
        uniform float uTime;
        uniform float uMagic;
        attribute float aScale;
        attribute float aOffset;
        varying float vTwinkle;
        void main() {
          vec3 pos = position;
          pos += normalize(pos) * sin(uTime * 3.0) * 0.02;
          if(uMagic > 0.5) pos *= 1.0 + sin(uTime * 12.0 + aOffset) * 0.05;
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_Position = projectionMatrix * mvPosition;
          gl_PointSize = aScale * (450.0 / -mvPosition.z);
          vTwinkle = 0.2 + 0.8 * pow(0.5 + 0.5 * sin(uTime * 8.0 + aOffset * 0.1), 5.0);
        }
      `,
      fragmentShader: `
        uniform vec3 uColor;
        varying float vTwinkle;
        void main() {
          float r = distance(gl_PointCoord, vec2(0.5));
          if (r > 0.5) discard;
          gl_FragColor = vec4(uColor, vTwinkle * (1.0 - r * 2.0) * 0.18);
        }
      `
    });
    const heartPoints = new THREE.Points(heartGeo, heartMat);
    heartPoints.position.set(0, 9.4, 0);
    treeGroup.add(heartPoints);

    const snowGeo = new THREE.BufferGeometry();
    const snowPosData = new Float32Array(CONFIG.SNOW_PARTICLES * 3);
    const snowDriftData = new Float32Array(CONFIG.SNOW_PARTICLES);
    const snowScalesData = new Float32Array(CONFIG.SNOW_PARTICLES);
    for(let i=0; i<CONFIG.SNOW_PARTICLES; i++){
      snowPosData[i*3] = (Math.random()-0.5)*70;
      snowPosData[i*3+1] = Math.random()*35;
      snowPosData[i*3+2] = (Math.random()-0.5)*70;
      snowDriftData[i] = Math.random() * Math.PI * 2;
      snowScalesData[i] = 0.6 + Math.random() * 0.5;
    }
    snowGeo.setAttribute('position', new THREE.BufferAttribute(snowPosData, 3));
    snowGeo.setAttribute('aScale', new THREE.BufferAttribute(snowScalesData, 1));
    snowGeo.setAttribute('aOffset', new THREE.BufferAttribute(snowDriftData, 1));
    const snowMat = new THREE.ShaderMaterial({
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
      uniforms: { uTime: { value: 0 } },
      vertexShader: `
        uniform float uTime;
        attribute float aScale;
        attribute float aOffset;
        void main() {
          vec3 pos = position;
          pos.x += sin(uTime * 0.4 + aOffset) * 2.0;
          pos.z += cos(uTime * 0.2 + aOffset) * 1.5;
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_Position = projectionMatrix * mvPosition;
          gl_PointSize = aScale * (250.0 / -mvPosition.z);
        }
      `,
      fragmentShader: `
        void main() {
          float r = distance(gl_PointCoord, vec2(0.5));
          if (r > 0.5) discard;
          gl_FragColor = vec4(1.0, 1.0, 1.0, pow(1.0 - (r * 2.0), 3.0) * 0.5);
        }
      `
    });
    const snowPoints = new THREE.Points(snowGeo, snowMat);
    scene.add(snowPoints);

    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloom = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), CONFIG.BLOOM_STRENGTH, 0.4, 0.85);
    composer.addPass(bloom);
    composer.addPass(new OutputPass());

    const clock = new THREE.Clock();
    const animate = () => {
      const time = clock.getElapsedTime();
      const isMagic = magicRef.current;

      treeMat.uniforms.uTime.value = time;
      treeMat.uniforms.uMagic.value = THREE.MathUtils.lerp(treeMat.uniforms.uMagic.value, isMagic ? 1.0 : 0.0, 0.1);
      heartMat.uniforms.uTime.value = time;
      heartMat.uniforms.uMagic.value = isMagic ? 1.0 : 0.0;
      snowMat.uniforms.uTime.value = time;
      wishMat.uniforms.uTime.value = time;
      spiralMat.uniforms.uTime.value = time;
      silverMat.uniforms.uTime.value = time;

      treeGroup.rotation.y = time * 0.25;
      heartPoints.rotation.y = Math.sin(time * 0.5) * 0.2;
      
      const blink = Math.pow(0.5 + 0.5 * Math.sin(time * 8.0), 4.0);
      starGlowLight.intensity = (0.25 + blink * 0.5) * (isMagic ? 1.5 : 1.0);

      fairyLightsRef.current.forEach(f => {
        const pulse = 0.4 + 0.6 * Math.sin(time * 4 + f.offset);
        f.light.intensity = pulse * (isMagic ? 3 : 1.0);
      });

      photoMeshesRef.current.forEach((frame, i) => {
        frame.rotation.y += 0.015;
        frame.position.y += Math.sin(time * 1.5 + i) * 0.003;
        frame.scale.setScalar(isMagic ? 1.0 + Math.sin(time * 4 + i) * 0.06 : 1.0);
      });

      // --- SPIRAL METEOR ANIMATION ---
      const spiralCycle = 18.0; 
      const prog = (time % spiralCycle) / spiralCycle;
      const spP = spiralGeo.attributes.position.array as Float32Array;
      const spS = spiralGeo.attributes.size.array as Float32Array;
      const spO = spiralGeo.attributes.opacity.array as Float32Array;

      const trailLength = 0.85; 

      for (let i = 0; i < CONFIG.SPIRAL_METEOR_PARTICLES; i++) {
        const iNorm = i / CONFIG.SPIRAL_METEOR_PARTICLES;
        const tProgress = Math.max(0, prog - (iNorm * trailLength));
        
        const y = tProgress * 10.0;
        const orbitAngle = tProgress * Math.PI * 12.0; 
        const currentMaxRadius = (9 - y) / 9 * 3.6 + 0.6;
        
        const jitter = (Math.random() - 0.5) * 0.18 * (1.0 - iNorm);
        spP[i * 3] = Math.cos(orbitAngle) * (currentMaxRadius + jitter);
        spP[i * 3 + 1] = y;
        spP[i * 3 + 2] = Math.sin(orbitAngle) * (currentMaxRadius + jitter);
        
        const fadeOut = Math.pow(1.0 - iNorm, 1.4);
        const visibility = (tProgress < 0.01 || tProgress > 0.99) ? 0 : 1;
        
        spS[i] = (i < 8 ? 0.38 : 0.06 + Math.random() * 0.1) * fadeOut;
        spO[i] = fadeOut * visibility * 0.75;
      }
      spiralGeo.attributes.position.needsUpdate = true;
      spiralGeo.attributes.size.needsUpdate = true;
      spiralGeo.attributes.opacity.needsUpdate = true;

      // --- WISH SHOOTING STAR (REFINED FOR FAST STREAMLINED EFFECT) ---
      if (wishAnimRef.current.active) {
        wishShootingStar.visible = true;
        const duration = 1200; // Faster speed
        const elapsed = (Date.now() - wishAnimRef.current.startTime) / duration;
        
        if (elapsed > 1.8) { // Finished animation (longer to allow tail to fade)
          wishAnimRef.current.active = false;
          wishShootingStar.visible = false;
        } else {
          const wP = wishGeo.attributes.position.array as Float32Array;
          const wS = wishGeo.attributes.size.array as Float32Array;
          const wO = wishGeo.attributes.opacity.array as Float32Array;
          
          // Path: From bottom-left to top-right behind the tree
          const start = new THREE.Vector3(-45, -15, -10); 
          const end = new THREE.Vector3(45, 35, -10);
          
          // trailLF defines the "tail length". We want it to be a segment, not a growing line.
          const trailLF = 0.35; 

          for (let i = 0; i < CONFIG.WISH_METEOR_PARTICLES; i++) {
            const iNorm = i / CONFIG.WISH_METEOR_PARTICLES;
            // Particles are spaced behind the leading edge
            const pProg = elapsed - (iNorm * trailLF);
            
            // Constrain to active range so we don't draw particles before the head starts
            const isVisible = (pProg > 0.0 && pProg < 1.0) ? 1.0 : 0.0;
            const activeProg = Math.max(0.0, Math.min(1.0, pProg));
            
            const basePos = new THREE.Vector3().lerpVectors(start, end, activeProg);
            
            // Taper: head is thicker, tail is thinner.
            const taper = Math.pow(1.0 - iNorm, 0.45); 
            const jitter = 0.85 * taper; // Slightly thicker core for streamlined look
            
            wP[i * 3] = basePos.x + (Math.random() - 0.5) * jitter;
            wP[i * 3 + 1] = basePos.y + (Math.random() - 0.5) * jitter;
            wP[i * 3 + 2] = basePos.z + (Math.random() - 0.5) * jitter * 0.3;
            
            // Size: Head is big (sparkly), tail is small.
            const headSize = 0.08 + Math.random() * 0.04;
            const tailSize = 0.005 + Math.random() * 0.02;
            const finalSize = THREE.MathUtils.lerp(headSize, tailSize, Math.pow(iNorm, 1.2));
            
            wS[i] = finalSize * isVisible;
            
            // Opacity: Leading particles are bright, tail fades.
            const tailFade = Math.pow(1.0 - iNorm, 0.8);
            wO[i] = isVisible * tailFade * (0.8 + Math.random() * 0.2);
          }
          wishGeo.attributes.position.needsUpdate = true;
          wishGeo.attributes.size.needsUpdate = true;
          wishGeo.attributes.opacity.needsUpdate = true;
        }
      }

      const snPArr = snowGeo.attributes.position.array as Float32Array;
      for(let i=0; i<CONFIG.SNOW_PARTICLES; i++) {
        snPArr[i*3+1] -= (0.02 + Math.random() * 0.05) * (isMagic ? 5.0 : 1.0) * (1.15 + Math.sin(time + i) * 0.5);
        if(snPArr[i*3+1] < -6) snPArr[i*3+1] = 32;
      }
      snowGeo.attributes.position.needsUpdate = true;

      bloom.strength = (CONFIG.BLOOM_STRENGTH + (isMagic ? 0.3 : 0)) * (0.9 + 0.1 * Math.sin(time * 2.5));
      controls.update();
      composer.render();
      requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      composer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (mountRef.current) mountRef.current.removeChild(renderer.domElement);
      renderer.dispose(); composer.dispose();
      treeGeo.dispose(); treeMat.dispose(); silverGeo.dispose(); silverMat.dispose();
      wishGeo.dispose(); wishMat.dispose(); heartGeo.dispose(); heartMat.dispose(); 
      snowGeo.dispose(); snowMat.dispose(); spiralGeo.dispose(); spiralMat.dispose();
    };
  }, []);

  return <div ref={mountRef} className="w-full h-full" />;
};

export default PinkParticleTreeScene;
