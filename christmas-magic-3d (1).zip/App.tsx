import React, { useState, useEffect, useRef } from 'react';
import PinkParticleTreeScene from './components/PinkParticleTreeScene';
import { Info, Hand, History, X, Heart, Send, Image as ImageIcon, Plus, Camera, Sparkles, Loader2 } from 'lucide-react';

const App: React.FC = () => {
  const [showEntranceModal, setShowEntranceModal] = useState(true);
  const [isInitializing, setIsInitializing] = useState(false);
  const [wishes, setWishes] = useState<string[]>([]);
  const [showWishList, setShowWishList] = useState(false);
  const [isGestureActive, setIsGestureActive] = useState(false);
  const [isMagicSparkling, setIsMagicSparkling] = useState(false);
  const [wishText, setWishText] = useState('');
  const [wishTrigger, setWishTrigger] = useState(0);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInstance = useRef<any>(null);
  const handsInstance = useRef<any>(null);

  useEffect(() => {
    const savedWishes = localStorage.getItem('magic_wishes');
    if (savedWishes) setWishes(JSON.parse(savedWishes));
    
    const savedPhotos = localStorage.getItem('magic_photos');
    if (savedPhotos) setPhotos(JSON.parse(savedPhotos));
  }, []);

  const handleSendWish = () => {
    if (!wishText.trim()) return;
    const newWishes = [wishText, ...wishes];
    setWishes(newWishes);
    localStorage.setItem('magic_wishes', JSON.stringify(newWishes));
    setWishText('');
    setWishTrigger(Date.now());
    
    setShowSuccessMessage(false);
    setTimeout(() => {
        setShowSuccessMessage(true);
    }, 50);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      const newPhotos = [...photos, result].slice(-6);
      setPhotos(newPhotos);
      localStorage.setItem('magic_photos', JSON.stringify(newPhotos));
    };
    reader.readAsDataURL(file);
  };

  /**
   * Initialize Camera and Gesture Recognition
   */
  const initializeMagic = async () => {
    setIsInitializing(true);
    
    try {
      if (!navigator.mediaDevices) {
        throw new Error("Media devices are not supported in this browser or context.");
      }

      setIsGestureActive(true);

      // Access MediaPipe from global window object
      const HandsConstructor = (window as any).Hands;
      const CameraConstructor = (window as any).Camera;

      if (!HandsConstructor || !CameraConstructor) {
        throw new Error("Magic components are still loading. Please wait a moment.");
      }

      // Initialize Hands if not already done
      if (!handsInstance.current) {
        handsInstance.current = new HandsConstructor({
          locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
        });

        handsInstance.current.setOptions({
          maxNumHands: 1,
          modelComplexity: 1,
          minDetectionConfidence: 0.7,
          minTrackingConfidence: 0.7
        });

        handsInstance.current.onResults((results: any) => {
          if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
            const landmarks = results.multiHandLandmarks[0];
            const wrist = landmarks[0];
            const middleTip = landmarks[12];
            setIsMagicSparkling(middleTip.y < wrist.y - 0.15);
          } else {
            setIsMagicSparkling(false);
          }
        });
      }

      // We skip preemptive enumerateDevices check as it can return empty results 
      // on many browsers before permissions are explicitly requested via getUserMedia.
      
      let attempts = 0;
      const checkVideoRef = setInterval(async () => {
        attempts++;
        if (videoRef.current) {
          clearInterval(checkVideoRef);
          
          cameraInstance.current = new CameraConstructor(videoRef.current, {
            onFrame: async () => {
              if (handsInstance.current) {
                await handsInstance.current.send({ image: videoRef.current! });
              }
            },
            width: 640,
            height: 480
          });

          try {
            await cameraInstance.current.start();
            setShowEntranceModal(false);
            setIsInitializing(false);
          } catch (camErr: any) {
            console.error("Camera start failed:", camErr);
            setIsInitializing(false);
            setIsGestureActive(false);
            
            // Handle specific errors for clearer user guidance
            if (camErr.name === 'NotFoundError' || camErr.message?.includes('found')) {
              alert("No camera hardware found on this device. You can still experience the magic without gestures!");
            } else if (camErr.name === 'NotAllowedError') {
              alert("Camera access was denied. Please check your browser permissions to enable gestures.");
            } else {
              alert("Failed to connect to magic lens. Continuing in standard mode.");
            }
            setShowEntranceModal(false);
          }
        }
        
        if (attempts > 50) { 
          clearInterval(checkVideoRef);
          setIsInitializing(false);
          alert("Initialization timed out. Loading standard mode.");
          setShowEntranceModal(false);
        }
      }, 100);

    } catch (err: any) {
      console.error("Magic initialization failed:", err);
      alert(err.message || "Failed to initialize magic lens. Loading standard mode.");
      setIsGestureActive(false);
      setIsInitializing(false);
      setShowEntranceModal(false);
    }
  };

  useEffect(() => {
    if (showSuccessMessage) {
      const timer = setTimeout(() => {
        setShowSuccessMessage(false);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [showSuccessMessage]);

  useEffect(() => {
    return () => {
      if (cameraInstance.current) {
        try { cameraInstance.current.stop(); } catch(e) {}
      }
      if (handsInstance.current) {
        try { handsInstance.current.close(); } catch(e) {}
      }
    };
  }, []);

  return (
    <div className="relative w-full h-screen bg-[#050108] overflow-hidden">
      {/* 3D Scene */}
      <PinkParticleTreeScene isMagicTriggered={isMagicSparkling} wishTrigger={wishTrigger} photos={photos} />
      
      <div className="absolute inset-0 magic-overlay" />

      {/* Entrance Modal */}
      {showEntranceModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#050108]/98 backdrop-blur-2xl px-6">
          <div className="max-w-md w-full text-center space-y-12 animate-fade-in">
            <div className="flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-pink-500 blur-3xl opacity-30 animate-pulse" />
                <Sparkles className="w-24 h-24 text-pink-400 relative z-10" />
              </div>
            </div>
            
            <div className="space-y-4">
              <h2 className="text-4xl font-bold title-gradient tracking-[0.2em]">MAGIC PORTAL</h2>
              <p className="text-pink-200/70 text-sm leading-relaxed tracking-wide font-light">
                Enable your camera to interact with the magic tree using hand gestures.<br/>
                No video data leaves your device.
              </p>
            </div>

            <div className="flex flex-col gap-5">
              <button 
                onClick={initializeMagic}
                disabled={isInitializing}
                className="w-full py-5 bg-pink-500 hover:bg-pink-400 disabled:bg-pink-800 text-white rounded-[2rem] font-bold tracking-[0.3em] uppercase transition-all shadow-[0_15px_50px_rgba(255,158,181,0.4)] flex items-center justify-center gap-3 active:scale-95 group"
              >
                {isInitializing ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <Camera className="w-6 h-6 group-hover:rotate-12 transition-transform" />
                )}
                {isInitializing ? 'WAKING MAGIC...' : 'ENABLE MAGIC CAMERA'}
              </button>
              <button 
                onClick={() => setShowEntranceModal(false)}
                className="w-full py-5 bg-white/5 hover:bg-white/10 text-white/30 rounded-[2rem] font-medium tracking-[0.3em] uppercase transition-all border border-white/5"
              >
                EXPERIENCE WITHOUT
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Header UI */}
      <div className="absolute top-0 left-0 w-full p-8 flex justify-between items-start pointer-events-none z-20">
        <div className="animate-fade-in" style={{ animationDelay: '0.3s' }}>
          <h1 className="text-white text-4xl md:text-5xl font-bold tracking-[0.2em] title-gradient drop-shadow-[0_0_25px_rgba(255,158,181,0.6)]">
            NEW YEAR MAGIC
          </h1>
          <p className="text-pink-300/60 text-[10px] md:text-xs mt-2 uppercase tracking-[0.6em] font-medium pl-1">energy resonance • 2026</p>
        </div>

        <div className="flex gap-4 pointer-events-auto items-center">
          <input type="file" ref={fileInputRef} onChange={handlePhotoUpload} accept="image/*" className="hidden" />
          <button 
            onClick={() => fileInputRef.current?.click()} 
            className="p-3 bg-yellow-500/10 hover:bg-yellow-500/20 rounded-full border border-yellow-500/30 transition-all backdrop-blur-md relative shadow-lg group"
            title="Hang a Memory"
          >
            <ImageIcon className="w-5 h-5 text-yellow-200" />
            <div className="absolute -top-1 -right-1 bg-yellow-500 rounded-full p-0.5 border border-black group-hover:scale-110 transition-transform"><Plus className="w-2.5 h-2.5 text-black" /></div>
          </button>
          <button 
            onClick={() => setShowWishList(!showWishList)} 
            className="p-3 bg-pink-500/10 hover:bg-pink-500/20 rounded-full border border-pink-500/30 transition-all backdrop-blur-md shadow-lg"
            title="Wish History"
          >
            <History className="w-5 h-5 text-pink-200" />
          </button>
        </div>
      </div>

      {/* Wish Input */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-full max-w-md px-6 z-30 pointer-events-auto">
        <div className="relative group w-full">
          <input 
            type="text"
            value={wishText}
            onChange={(e) => setWishText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendWish()}
            placeholder="Whisper a wish to the stars..."
            className="w-full bg-black/40 border border-pink-500/30 rounded-full py-4 px-8 text-pink-100 placeholder-pink-300/20 focus:outline-none focus:border-pink-500/60 transition-all backdrop-blur-2xl shadow-[0_0_40px_rgba(255,158,181,0.1)]"
          />
          <button onClick={handleSendWish} className="absolute right-2.5 top-1/2 -translate-y-1/2 p-2.5 bg-pink-500 hover:bg-pink-400 text-white rounded-full transition-all shadow-lg active:scale-90">
            <Send className="w-4 h-4" />
          </button>
        </div>
        
        {showSuccessMessage && (
          <div className="mt-4 success-container text-center animate-fade-in">
             <span className="silky-sparkle text-[9px] uppercase tracking-[0.4em]">The universe is listening...</span>
          </div>
        )}
      </div>

      {/* Small Avatar Screen (Bottom-Right) */}
      <div 
        id="camera-container"
        className={`absolute bottom-10 right-10 w-48 h-32 md:w-56 md:h-40 rounded-[2.5rem] border-2 border-pink-500/50 overflow-hidden shadow-[0_0_60px_rgba(255,158,181,0.4)] backdrop-blur-md transition-all duration-1000 z-40 ${isGestureActive ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-20 opacity-0 scale-90 pointer-events-none'}`}
      >
        <video 
          ref={videoRef} 
          className="w-full h-full object-cover scale-x-[-1] contrast-125 brightness-110 grayscale-[0.3]" 
          playsInline 
          muted 
        />
        
        <div className="absolute inset-0 bg-gradient-to-t from-pink-900/60 via-transparent to-transparent pointer-events-none" />
        
        <div className="absolute top-3 left-3 flex items-center gap-2 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
           <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse shadow-[0_0_12px_#ef4444]" />
           <span className="text-[8px] font-black tracking-widest text-white/90 uppercase">Magic Link</span>
        </div>

        <div className="absolute top-0 left-0 w-full h-[2px] bg-pink-400/80 shadow-[0_0_20px_rgba(244,114,182,1)] animate-scan-line" />
        
        <div className="absolute bottom-3 right-4">
           <div className={`p-2.5 rounded-full transition-all duration-300 ${isMagicSparkling ? 'bg-pink-500 shadow-[0_0_20px_#ec4899] scale-110' : 'bg-white/10 border border-white/20'}`}>
              <Hand className={`w-3.5 h-3.5 text-white ${isMagicSparkling ? 'animate-bounce' : 'opacity-40'}`} />
           </div>
        </div>
      </div>

      {/* Interaction Banner */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 pointer-events-none z-30 flex flex-col items-center">
        {isMagicSparkling && (
          <div className="mb-2 text-pink-300 font-bold tracking-[1.4em] uppercase text-[9px] animate-pulse drop-shadow-[0_0_10px_rgba(244,114,182,0.8)]">
            RESONATING
          </div>
        )}
        <div className={`px-8 py-2.5 rounded-full border transition-all duration-1000 flex items-center gap-4 backdrop-blur-3xl ${isMagicSparkling ? 'bg-pink-500/40 border-pink-400 scale-105 shadow-[0_0_60px_rgba(255,158,181,0.6)]' : 'bg-white/5 border-white/10 opacity-30'}`}>
          <Hand className={`w-4 h-4 ${isMagicSparkling ? 'text-pink-300' : 'text-white'}`} />
          <span className="text-[10px] font-black tracking-[0.5em] text-white">
            {isMagicSparkling ? 'MAGIC FLOWING' : 'OPEN PALM FOR MAGIC'}
          </span>
        </div>
      </div>

      {/* Wish History Scroll */}
      {showWishList && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-black/80 backdrop-blur-2xl animate-fade-in">
          <div className="bg-[#0f0a15] border border-pink-500/30 rounded-[3.5rem] w-full max-w-xl p-12 relative overflow-hidden shadow-2xl">
             <button onClick={() => setShowWishList(false)} className="absolute top-10 right-10 text-pink-300/40 hover:text-white transition-colors">
               <X className="w-8 h-8" />
             </button>
             <h2 className="text-4xl font-serif text-pink-100 mb-10 flex items-center gap-4">
               <Heart className="w-8 h-8 text-pink-500 fill-current" />
               Eternal Wishes
             </h2>
             <div className="max-h-[25rem] overflow-y-auto space-y-4 pr-4 custom-scrollbar">
                {wishes.length === 0 ? (
                  <p className="text-pink-300/20 italic py-20 text-center tracking-[0.2em] uppercase text-xs">The scroll is empty...</p>
                ) : wishes.map((w, i) => (
                  <div key={i} className="p-6 bg-white/5 rounded-[2rem] border border-white/5 text-pink-100/80 leading-relaxed text-sm font-light">
                    {w}
                  </div>
                ))}
             </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes scan-line {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        .animate-scan-line {
          animation: scan-line 4s linear infinite;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255,255,255,0.02);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 158, 181, 0.4);
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
};

export default App;